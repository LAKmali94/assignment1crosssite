<!doctype html>
<html>
  <head>

        <title>User Login</title>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


        


    </head>

    <body>
      <!-- navbar start -->
      <nav class="navbar navbar-inverse">
        <div class="container-fluid">
          <div class="navbar-header">
            <a class="navbar-brand" href="index.php">CIRCLE</a>
          </div>
          <ul class="nav navbar-nav">

            <?php
              if(!isset($_COOKIE['Assignment2_session_cookie'])) {
                echo "<li><a href='user-profile.php'></t>Profile</t></a></li>";
              }
            ?>

          </ul>
          <ul class="nav navbar-nav navbar-right">

          <?php
            if(!isset($_COOKIE['Assignment2_session_cookie'])) {
              echo "<li><a href='user-login.php'> Log In </a></li>";
            }
          ?>

          <?php
            if(isset($_COOKIE['Assignment2_session_cookie'])) {
              echo "<li><a href='user-logout.php'> Log Out </a></li>";
            }
          ?>

          </ul>
        </div>
      </nav>
      <!-- navbar end -->

      <div class="container">
        <div class="row" align="center" style="padding-top: 100px;">
          <div class="col-12">
            <div class="card">
              <h5 class="card-header">Profile Details</h5>
              <div class="card-body">
                <div class="row">
                  <div class="col-sm-2"></div>
                    <div class="col-sm-8">


          						<?php
          						if(isset($_COOKIE['Assignment2_session_cookie']))
          						{
          							session_start();
          							if ($_POST['csrf_Token'] == $_COOKIE['csrf_token'])
          							{
          								$fname=$_POST['name'];
          								$hometown=$_POST['hometown'];
          								$university=$_POST['university'];
          								$age=$_POST['age'];

          								echo "<div class='alert alert-primary' role='alert'>".$fname."</div>";
          								echo "<div class='alert alert-secondary' role='alert'>".$hometown."</div>";
          								echo "<div class='alert alert-success' role='alert'>".$university."</div>";
          								echo "<div class='alert alert-info' role='alert'>".$age."</div>";

          							}
          							else
          							{
          								echo "<script>alert('WARNING :: CSRF Found !!!')</script>";
          							}

          						}
          						?>


                    </div>
                  <div class="col-sm-2"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>


    </body>
  </html>
